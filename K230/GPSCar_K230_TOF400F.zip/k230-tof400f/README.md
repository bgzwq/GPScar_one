# K230 + TOF400F 联调

目前已在庐山派 K230 1G、CanMV v1.5-legacy-413737f 上验证 TOF400F 的自动上报可以经 UART3 接收。UART2 留给 STM32F103ZET6。这里只归档串口联调、协议解析和视觉观察工具，尚未实现自动抓取。

## 当前接线

| 信号 | 庐山派 40Pin 物理脚 | 对端 |
|---|---|---|
| UART3_RX | 第 40 脚 / GPIO33 | TOF400F 绿线 TX |
| TOF 供电 | 3V3、GND | 红线 VIN、黑线 GND |
| UART2_TX | 第 11 脚 / GPIO5 | STM32 PA10（RX） |
| UART2_RX | 第 13 脚 / GPIO6 | STM32 PA9（TX） |

两板共地。TOF 自动上报只接收，白线 RX、黄线 SDA、蓝线 SCL 悬空。GPIO32（物理第 37 脚）在 UART3 脚本中配置为 TX，但不发送查询。换线前断电，测距联调时保持舵机断电。线色以模块端引脚标识为准。

参考：[庐山派 UART 引脚表](https://wiki.lckfb.com/zh-hans/lushan-pi-k230/basic/uart.html)、[TOF400F 规格书](https://myosuploads3.banggood.com/products/20210224/20210224033328TOF400F.pdf)。

## 实板复现

用 CanMV IDE 打开并运行 [`F_tof_uart3_receive_only.py`](uart-diagnostics/F_tof_uart3_receive_only.py)。脚本只读 UART3（115200、8N1），无需上传库，不写模块配置。

实测结尾为 `FINISHED total_rx=140`。抽查的有效 CRC 帧：

| 原始帧 | 模块上报值 |
|---|---|
| `01 03 02 00 47 F8 76` | 71 mm |
| `01 03 02 00 48 B8 72` | 72 mm |

此前 UART1 只接收为 0 字节；UART2 临时对照收到 140 字节、抽查读数为 98–99 mm。UART3 上的读数未与尺子比对，白卡标定和夹爪融合均未完成。

## 文件

- [`tof400f.py`](tof400f.py)：Modbus CRC、断帧恢复、无效值及超时处理。包含早期 UART1 查询示例的驱动入口；UART3 上板验证使用上述独立只收脚本。
- [`uart-diagnostics/`](uart-diagnostics/)：已用过的 UART1/2/3 回环、查询和只接收对照脚本。
- [`uart1-history.md`](uart1-history.md)：早期 UART1 查询和视觉观察流程；不是现用接线。
- [`project-notes.md`](project-notes.md)：当前架构、原工程核对和待标定项。

在本目录运行电脑端回归测试：`python -m unittest discover -s tests -v`。
