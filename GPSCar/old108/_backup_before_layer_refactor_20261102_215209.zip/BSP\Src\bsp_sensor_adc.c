/***
	*************************************************************************************************
	*	@version V1.0
	*	@brief   ��Դ/����/ʪ�� ADC���� (ADC1 + DMAѭ��ɨ��)
   *************************************************************************************************
   *  @description
	*
>>>>> �ļ�˵����
	*
	*  1. ADC1 ɨ��ģʽ + DMA2 Stream0 Channel0 ѭ������, ��̨�Զ�ˢ��4��ͨ��
	*  2. ͨ��˳��(Rank1~4): PA3(IN3) PA4(IN4) PB0(IN8) PC4(IN14)
	*  3. ����ʱ��144����, �ʺϵ�Դ��ѹ/����/ʪ���������ź�
	*  4. ע��: PB0/PC4 ��֧�� ADC1/ADC2, �������̶�ʹ�� ADC1
	*
	************************************************************************************************
***/

#include "sensor_adc.h"

static volatile uint16_t s_adcBuf[ADC_CH_NUM];	// DMAĿ�껺��, ˳����Rankһ��

/*************************************************************************************************
*	�� �� ��:	SensorADC_Init
*
*	��������:	��ʼ��GPIO��ADC1ɨ��ģʽ��DMAѭ������
*
*************************************************************************************************/
void SensorADC_Init(void)
{
	GPIO_InitTypeDef       GPIO_InitStructure;
	ADC_InitTypeDef        ADC_InitStructure;
	ADC_CommonInitTypeDef  ADC_CommonInitStructure;
	DMA_InitTypeDef        DMA_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA |
						   RCC_AHB1Periph_GPIOB |
						   RCC_AHB1Periph_GPIOC, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);

	/* ģ������, �������� */
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4;		// PA3 PA4
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;					// PB0
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;					// PC4
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	/* DMA2 Stream0 Channel0 -> ADC1 */
	DMA_DeInit(DMA2_Stream0);
	DMA_InitStructure.DMA_Channel            = DMA_Channel_0;
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&ADC1->DR;
	DMA_InitStructure.DMA_Memory0BaseAddr    = (uint32_t)s_adcBuf;
	DMA_InitStructure.DMA_DIR                = DMA_DIR_PeripheralToMemory;
	DMA_InitStructure.DMA_BufferSize         = ADC_CH_NUM;
	DMA_InitStructure.DMA_PeripheralInc      = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc          = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize     = DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode               = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority           = DMA_Priority_High;
	DMA_InitStructure.DMA_FIFOMode           = DMA_FIFOMode_Disable;
	DMA_Init(DMA2_Stream0, &DMA_InitStructure);
	DMA_Cmd(DMA2_Stream0, ENABLE);

	/* ADCͨ������: ����ģʽ, PCLK2/4 = 21MHz */
	ADC_CommonInitStructure.ADC_Mode             = ADC_Mode_Independent;
	ADC_CommonInitStructure.ADC_Prescaler        = ADC_Prescaler_Div4;
	ADC_CommonInitStructure.ADC_DMAAccessMode    = ADC_DMAAccessMode_Disabled;
	ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
	ADC_CommonInit(&ADC_CommonInitStructure);

	/* ADC1: ɨ��+����ת��, 12λ */
	ADC_InitStructure.ADC_Resolution           = ADC_Resolution_12b;
	ADC_InitStructure.ADC_ScanConvMode         = ENABLE;
	ADC_InitStructure.ADC_ContinuousConvMode   = ENABLE;
	ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
	ADC_InitStructure.ADC_DataAlign            = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_NbrOfConversion      = ADC_CH_NUM;
	ADC_Init(ADC1, &ADC_InitStructure);

	/* ɨ��˳������� SensorADC_TypeDef ö��һ�� */
	ADC_RegularChannelConfig(ADC1, ADC_Channel_3,  1, ADC_SampleTime_144Cycles);	// PA3 ��Դ1
	ADC_RegularChannelConfig(ADC1, ADC_Channel_4,  2, ADC_SampleTime_144Cycles);	// PA4 ��Դ2
	ADC_RegularChannelConfig(ADC1, ADC_Channel_8,  3, ADC_SampleTime_144Cycles);	// PB0 ����
	ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 4, ADC_SampleTime_144Cycles);	// PC4 ʪ��

	ADC_DMARequestAfterLastTransferCmd(ADC1, ENABLE);
	ADC_DMACmd(ADC1, ENABLE);

	ADC_Cmd(ADC1, ENABLE);
	ADC_SoftwareStartConv(ADC1);
}

/*************************************************************************************************
*	�� �� ��:	SensorADC_GetRaw
*
*	��ڲ���:	ch - ͨ��ö��
*
*	�� �� ֵ:	ADCԭʼֵ 0~4095
*
*************************************************************************************************/
uint16_t SensorADC_GetRaw(SensorADC_TypeDef ch)
{
	if (ch >= ADC_CH_NUM) return 0;
	return s_adcBuf[ch];
}

/*************************************************************************************************
*	�� �� ��:	SensorADC_GetVoltage
*
*	��ڲ���:	ch - ͨ��ö��
*
*	�� �� ֵ:	���ŵ�ѹ, ��λV
*
*	˵    ��:	����Դ��⾭��ѹ�������, �����г��Ϸ�ѹ��
*
*************************************************************************************************/
float SensorADC_GetVoltage(SensorADC_TypeDef ch)
{
	return SensorADC_GetRaw(ch) * ADC_REF_VOLTAGE / ADC_FULL_SCALE;
}
