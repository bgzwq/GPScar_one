# 按用户“串口自检.py”的串口初始化和读写节奏测试 TOF400F。
# 临时使用 UART2：物理11脚 GPIO5 TX -> TOF RX；物理13脚 GPIO6 RX <- TOF TX。
# STM32两根串口线必须断开，机械臂和舵机保持断电；移除所有TX/RX回环短接线。
# 模块VIN接3.3V电源输出，GND共地。本文件不依赖tof400f.py，不修改模块参数。
import time
import os
import sys
from machine import UART, FPIOA

QUERY = b'\x01\x03\x00\x10\x00\x01\x85\xCF'
uart = None

try:
    # 以下初始化写法与用户原版串口自检一致，不显式填写timeout。
    fpioa = FPIOA()
    fpioa.set_function(5, fpioa.UART2_TXD)
    fpioa.set_function(6, fpioa.UART2_RXD)
    uart = UART(UART.UART2, baudrate=115200, bits=UART.EIGHTBITS,
                parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)
    print("TOF UART2 ORIGINAL-STYLE TEST - 2026-10-17")
    print("Remove loopback jumpers. STM32 UART disconnected; arm power OFF.")
    print("physical11 GPIO5 TX -> TOF RX; physical13 GPIO6 RX <- TOF TX")
    print("Same UART2 initialization as original; write -> sleep100 -> read64 -> sleep400")
    print("Only query: 01 03 00 10 00 01 85 CF; no configuration writes")
    print("Runtime:", sys.version)
    total_rx = 0
    for i in range(20):
        os.exitpoint()
        written = uart.write(QUERY)
        time.sleep_ms(100)
        data = uart.read(64)
        if data:
            total_rx += len(data)
            print("trial=%d write=%s rx=%d total_rx=%d RX=%s" %
                  (i + 1, written, len(data), total_rx,
                   " ".join("%02X" % value for value in data)))
        else:
            print("trial=%d write=%s rx=0 total_rx=%d" % (i + 1, written, total_rx))
        time.sleep_ms(400)
    print("FINISHED total_rx=%d" % total_rx)
    print("Raw-byte observation only; receiving bytes alone does not validate a distance.")
except KeyboardInterrupt:
    print("STOPPED")
except Exception as error:
    sys.print_exception(error)
finally:
    if uart is not None:
        uart.deinit()
