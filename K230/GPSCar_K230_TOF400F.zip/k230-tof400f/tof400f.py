"""TOF400F UART diagnostic driver. No robot/servo commands; no register writes.

Protocol: vendor TOF400F V2.0.1, register 0x0010, Modbus CRC16.
Receive timestamps describe UART arrival, NOT a sensor exposure timestamp.
This driver cannot prove which visible object produced a distance.
Compatible with CanMV MicroPython and CPython (for protocol tests).
"""

import time

DRIVER_REVISION = "2026-10-17-legacy-timeout10-direct"
# Firmware 413737f never enters machine_uart_read()'s loop with timeout=0.
# Use a positive timeout and do not gate reception on its zero-timeout poll.
UART_READ_TIMEOUT_MS = 10


def ticks_ms():
    if hasattr(time, "ticks_ms"):
        return time.ticks_ms()
    return int(time.monotonic() * 1000)


def ticks_diff(a, b):
    if hasattr(time, "ticks_diff"):
        return time.ticks_diff(a, b)
    return a - b


def crc16(data):
    crc = 0xFFFF
    for value in data:
        crc ^= value
        for _ in range(8):
            crc = (crc >> 1) ^ 0xA001 if crc & 1 else crc >> 1
    return crc


def with_crc(payload):
    crc = crc16(payload)
    return bytes(payload) + bytes((crc & 255, crc >> 8))


def read_distance_request(address=1):
    if not 1 <= address <= 247:
        raise ValueError("Use a unicast Modbus address, 1..247")
    return with_crc(bytes((address, 3, 0, 0x10, 0, 1)))


def hex_bytes(data):
    return " ".join("%02X" % value for value in data)


class FrameParser:
    """Recover complete, CRC-checked frames from fragmented/noisy UART input."""

    def __init__(self, address=1):
        read_distance_request(address)
        self.address = address
        self.buffer = bytearray()
        self.crc_errors = 0
        self.dropped_bytes = 0
        self.frames = 0

    def feed(self, data):
        if not data:
            return []
        self.buffer.extend(data)
        # Bound both RAM and time spent resynchronizing a noisy chunk.
        if len(self.buffer) > 256:
            self.dropped_bytes += len(self.buffer) - 256
            self.buffer = self.buffer[-256:]
        events = []
        while len(self.buffer) >= 2:
            if self.buffer[0] != self.address:
                del self.buffer[0]
                self.dropped_bytes += 1
                continue
            function = self.buffer[1]
            if function == 3:
                if len(self.buffer) < 3:
                    break
                if self.buffer[2] != 2:
                    del self.buffer[0]
                    self.dropped_bytes += 1
                    continue
                size = 7
            elif function == 6:
                size = 8
            elif function in (0x83, 0x86):
                size = 5
            else:
                del self.buffer[0]
                self.dropped_bytes += 1
                continue
            if len(self.buffer) < size:
                break
            frame = bytes(self.buffer[:size])
            expected = frame[-2] | (frame[-1] << 8)
            if crc16(frame[:-2]) != expected:
                self.crc_errors += 1
                del self.buffer[0]
                continue
            del self.buffer[:size]
            self.frames += 1
            if function == 3:
                events.append(("distance", (frame[3] << 8) | frame[4], frame))
            elif function & 0x80:
                events.append(("exception", frame[2], frame))
            else:
                events.append(("write_ack", (frame[2] << 8) | frame[3], frame))
        return events


class RangeHistory:
    """Display-only rolling statistics. Never fill in an invalid/stale range."""

    def __init__(self, window=5, fresh_ms=700, spread_mm=20):
        if window < 1 or fresh_ms < 1 or spread_mm < 0:
            raise ValueError("Invalid history parameters")
        self.window = window
        self.fresh_ms = fresh_ms
        self.spread_limit = spread_mm
        self.samples = []
        self.last_ms = None
        self.raw_mm = None
        self.reason = "NO_DATA"
        self.sequence = 0

    def invalidate(self, reason, now):
        self.samples = []
        self.raw_mm = None
        self.last_ms = now
        self.reason = reason
        self.sequence += 1

    def record(self, raw_mm, now):
        # Vendor demo treats high byte 0xFF as invalid. The 4 m limit here is
        # only a diagnostic plausibility limit, not a robot working envelope.
        if raw_mm <= 0 or raw_mm >= 0xFF00 or raw_mm > 4000:
            self.invalidate("INVALID", now)
            return
        if self.last_ms is not None and ticks_diff(now, self.last_ms) > self.fresh_ms:
            self.samples = []
        self.samples.append((now, raw_mm))
        self.samples = self.samples[-self.window:]
        self.raw_mm = raw_mm
        self.last_ms = now
        self.reason = "RECEIVED"
        self.sequence += 1

    def snapshot(self, now):
        age = None if self.last_ms is None else ticks_diff(now, self.last_ms)
        result = {"status": self.reason, "raw_mm": self.raw_mm,
                  "median_mm": None, "spread_mm": None, "count": 0,
                  "age_ms": age, "sequence": self.sequence}
        if self.last_ms is None:
            return result
        if age < 0 or age > self.fresh_ms:
            result["status"] = "STALE"
            result["raw_mm"] = None
            return result
        values = sorted(value for stamp, value in self.samples
                        if 0 <= ticks_diff(now, stamp) <= self.fresh_ms)
        result["count"] = len(values)
        if not values:
            return result
        result["median_mm"] = values[len(values) // 2]
        result["spread_mm"] = values[-1] - values[0]
        if len(values) < self.window:
            result["status"] = "WARMUP"
        elif result["spread_mm"] > self.spread_limit:
            result["status"] = "UNSTABLE"
        else:
            result["status"] = "STABLE_RX"
        return result


class TOF400F:
    """Poll only register 0x0010; never configure, calibrate or reboot hardware.

    Existing unsolicited output can have the same format as a query reply.
    Therefore STABLE_RX only means stable received numbers, never confirmation
    of a newly acquired sensor measurement or association with a camera target.
    """

    def __init__(self, uart, address=1, poll_ms=120, debug_rx=False):
        if poll_ms < 30:
            raise ValueError("Polling interval must be at least 30 ms")
        self.uart = uart
        self.parser = FrameParser(address)
        self.history = RangeHistory()
        self.request = read_distance_request(address)
        self.poll_ms = poll_ms
        self.last_query_ms = None
        self.debug_rx = debug_rx
        self.rx_bytes = 0
        self.queries = 0
        self.last_frame = None

    def update(self, now=None):
        if now is None:
            now = ticks_ms()
        # Positive UART timeout is required by CanMV v1.5-legacy 413737f.
        # Read a bounded chunk directly: any() uses a separate zero-timeout poll.
        chunk = self.uart.read(256)
        if chunk:
            self.rx_bytes += len(chunk)
            if self.debug_rx:
                print("RX", hex_bytes(chunk))
            for kind, value, frame in self.parser.feed(chunk):
                self.last_frame = frame
                if kind == "distance":
                    self.history.record(value, now)
                elif kind == "exception":
                    self.history.invalidate("EXCEPTION_%02X" % value, now)
        if self.last_query_ms is None or ticks_diff(now, self.last_query_ms) >= self.poll_ms:
            count = self.uart.write(self.request)
            if count != len(self.request):
                raise OSError("Incomplete TOF UART write: %s" % count)
            self.last_query_ms = now
            self.queries += 1
        return self.history.snapshot(now)


def open_k230_uart():
    """LuShan 40-pin header: physical 8=GPIO3 TX, 10=GPIO4 RX."""
    from machine import UART, FPIOA
    fpioa = FPIOA()
    fpioa.set_function(3, FPIOA.UART1_TXD)
    fpioa.set_function(4, FPIOA.UART1_RXD)
    return UART(UART.UART1, baudrate=115200, bits=UART.EIGHTBITS,
                parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE,
                timeout=UART_READ_TIMEOUT_MS)
