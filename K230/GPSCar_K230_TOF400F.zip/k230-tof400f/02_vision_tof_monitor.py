# Camera + independent TOF observation. NO STM32 UART, NO grasp commands.
# Copy tof400f.py to /sdcard; run this file from CanMV IDE.
import sys
import os
import time
import gc
import image
from media.sensor import Sensor
from media.display import Display
from media.media import MediaManager

if "/sdcard" not in sys.path:
    sys.path.append("/sdcard")

from tof400f import TOF400F, open_k230_uart, ticks_ms, ticks_diff, DRIVER_REVISION

WIDTH, HEIGHT = 640, 480
DISPLAY_WIDTH, DISPLAY_HEIGHT = 800, 480
VFLIP, HMIRROR = True, True  # Keep current project's image orientation.
# Starting values copied from the user's existing code. Recalibrate in IDE.
RED_THRESHOLD = (0, 100, 20, 127, 0, 127)
GREEN_THRESHOLD = (0, 100, -128, -23, 16, 76)
COLORS = ((1, "RED", RED_THRESHOLD, (255, 0, 0)),
          (3, "GREEN", GREEN_THRESHOLD, (0, 255, 0)))
PIXELS_THRESHOLD = 144
AREA_THRESHOLD = 144
LOG_INTERVAL_MS = 250
# Optional observation log. Overwrites ONLY this named diagnostic CSV when True.
SAVE_CSV = False
CSV_PATH = "/sdcard/pepper_observation.csv"

sensor = None
uart = None
log = None
display_ready = False
media_ready = False
sensor_running = False
try:
    print("OBSERVATION ONLY: no STM32 UART and no servo instructions")
    print("Driver revision:", DRIVER_REVISION)
    print("TOF is NOT yet associated with the selected color target.")
    print("Yellow image-center cross is NOT the calibrated grasp point.")
    print("Runtime:", sys.version)
    if hasattr(os, "uname"):
        print("Board:", os.uname())
    uart = open_k230_uart()
    tof = TOF400F(uart)
    sensor = Sensor(width=WIDTH, height=HEIGHT)
    sensor.reset()
    sensor.set_framesize(width=WIDTH, height=HEIGHT)
    sensor.set_pixformat(Sensor.RGB565)
    sensor.set_vflip(VFLIP)
    sensor.set_hmirror(HMIRROR)
    Display.init(Display.VIRT, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT,
                 fps=30, to_ide=True)
    display_ready = True
    MediaManager.init()
    media_ready = True
    sensor.run()
    sensor_running = True
    canvas = image.Image(DISPLAY_WIDTH, DISPLAY_HEIGHT, image.RGB565)
    for _ in range(30):
        os.exitpoint()
        sensor.snapshot()
        tof.update()
        time.sleep_ms(10)
    if SAVE_CSV:
        log = open(CSV_PATH, "w")
    header = ("t_ms,color,cx640,cy480,cx320,cy240,w,h,rect_area,pixels,"
              "tof_status,raw_mm,median_mm,span_mm,age_ms,rx_seq,"
              "image_start_ms,image_end_ms,range_associated")
    print(header)
    if log:
        log.write(header + "\n")
    start = ticks_ms()
    last_log = start
    frames = 0
    while True:
        os.exitpoint()
        tof.update()
        image_start = ticks_ms()
        img = sensor.snapshot()
        image_end = ticks_ms()
        best = None
        best_color = None
        best_area = 0
        # Separate searches avoid ambiguity in multi-threshold blob bitmasks.
        for cid, name, threshold, rgb in COLORS:
            for blob in img.find_blobs([threshold], pixels_threshold=PIXELS_THRESHOLD,
                                       area_threshold=AREA_THRESHOLD, merge=False):
                area = blob.w() * blob.h()
                if area > best_area:
                    best, best_color, best_area = blob, (cid, name, rgb), area
        now = ticks_ms()
        state = tof.update(now)
        img.draw_cross(WIDTH // 2, HEIGHT // 2, size=12, color=(255, 255, 0))
        if best is not None:
            cid, name, rgb = best_color
            img.draw_rectangle(*best.rect(), color=(255, 255, 255))
            img.draw_cross(best.cx(), best.cy(), size=10, color=rgb)
            img.draw_string_advanced(best.x(), max(0, best.y() - 22), 20, name, color=rgb)
            values = (cid, best.cx(), best.cy(), best.cx() // 2, best.cy() // 2,
                      best.w(), best.h(), best_area, best.pixels())
        else:
            values = (0, -1, -1, -1, -1, 0, 0, 0, 0)
        img.draw_string_advanced(4, 4, 20, "OBSERVE ONLY - NO ARM COMMAND", color=(255, 255, 0))
        img.draw_string_advanced(4, 30, 20, "TOF %s raw:%s mm" %
                                 (state["status"], state["raw_mm"]), color=(255, 255, 255))
        img.draw_string_advanced(4, 56, 20, "Range/target association: UNCALIBRATED",
                                 color=(255, 255, 0))
        canvas.clear()
        canvas.draw_image(img, (DISPLAY_WIDTH - WIDTH) // 2, 0)
        Display.show_image(canvas)
        if ticks_diff(now, last_log) >= LOG_INTERVAL_MS:
            fields = ((ticks_diff(now, start),) + values +
                      (state["status"], state["raw_mm"], state["median_mm"],
                       state["spread_mm"], state["age_ms"], state["sequence"],
                       ticks_diff(image_start, start), ticks_diff(image_end, start), 0))
            line = ",".join(str(value) for value in fields)
            print(line)
            if log:
                log.write(line + "\n")
                log.flush()
            last_log = now
        frames += 1
        if frames % 30 == 0:
            gc.collect()
except KeyboardInterrupt:
    print("STOPPED")
except Exception as error:
    sys.print_exception(error)
finally:
    if log is not None:
        log.close()
    if sensor_running:
        sensor.stop()
    if display_ready:
        Display.deinit()
    if uart is not None:
        uart.deinit()
    if media_ready:
        os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
        time.sleep_ms(100)
        MediaManager.deinit()
