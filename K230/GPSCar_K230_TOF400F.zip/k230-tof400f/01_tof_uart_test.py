# Run from CanMV IDE; copy tof400f.py to /sdcard first.
# TOF only: UART1 GPIO3/4. Does not open UART2 or send STM32 commands.
import sys
import os
import time

if "/sdcard" not in sys.path:
    sys.path.append("/sdcard")

from tof400f import (TOF400F, open_k230_uart, ticks_ms, ticks_diff, hex_bytes,
                    DRIVER_REVISION, UART_READ_TIMEOUT_MS)

DEBUG_RX = True       # Print binary receive chunks for the first wiring test.
RUN_SECONDS = 60      # Automatically stop; rerun for another observation.
PRINT_INTERVAL_MS = 500

uart = None
try:
    print("TOF400F diagnostic; robot motion is not commanded by this script")
    print("Driver revision:", DRIVER_REVISION)
    print("UART read timeout_ms=%d; DIRECT read, no any() gate" % UART_READ_TIMEOUT_MS)
    print("UART1: GPIO3 TX -> TOF RX; GPIO4 RX <- TOF TX; 115200 8N1")
    print("Only reading register 0x0010. Sensor settings are left unchanged.")
    print("Runtime:", sys.version)
    print("Platform:", sys.platform)
    if hasattr(os, "uname"):
        print("Board:", os.uname())
    uart = open_k230_uart()
    tof = TOF400F(uart, debug_rx=DEBUG_RX)
    start = ticks_ms()
    last_print = start
    while ticks_diff(ticks_ms(), start) < RUN_SECONDS * 1000:
        os.exitpoint()
        now = ticks_ms()
        state = tof.update(now)
        if ticks_diff(now, last_print) >= PRINT_INTERVAL_MS:
            print("t=%d status=%s raw=%s median=%s span=%s n=%d age=%s rx=%d frames=%d crc_bad=%d tx=%d" %
                  (ticks_diff(now, start), state["status"], state["raw_mm"],
                   state["median_mm"], state["spread_mm"], state["count"],
                   state["age_ms"], tof.rx_bytes, tof.parser.frames,
                   tof.parser.crc_errors, tof.queries))
            last_print = now
        time.sleep_ms(5)
    print("FINISHED. Last complete frame:",
          hex_bytes(tof.last_frame) if tof.last_frame else "NONE")
except KeyboardInterrupt:
    print("STOPPED")
except Exception as error:
    sys.print_exception(error)
finally:
    if uart is not None:
        uart.deinit()
