# Standalone CanMV K230 UART1 loopback diagnostic. No tof400f.py dependency.
# BEFORE RUNNING: disconnect TOF TX/RX and STM32 UART wires, keep servo power off.
# Connect ONLY K230 physical header pin 8 (GPIO3) to pin 10 (GPIO4).
# Never short either signal pin to a power pin. See README before wiring.
import os
import sys
import time
from machine import UART, FPIOA

READ_TIMEOUT_MS = 10


def show_hex(data):
    return " ".join("%02X" % value for value in data)


def drain(uart):
    # CanMV 413737f requires a positive timeout to attempt an actual read.
    start = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), start) < 100:
        os.exitpoint()
        uart.read(1)
        time.sleep_ms(2)


def check(uart, strategy, trial):
    drain(uart)
    expected = ("LUSHAN_UART1_%s_%d\r\n" % (strategy, trial)).encode()
    received = bytearray()
    written = uart.write(expected)
    peak_any = 0
    start = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), start) < 1000:
        os.exitpoint()
        available = uart.any() if strategy == "ANY" else 0
        if available > peak_any:
            peak_any = available
        if strategy == "ANY":
            # Control path: any() gate, with the corrected positive timeout.
            chunk = uart.read(256) if available else None
        else:
            # Only change: read one byte without gating on any().
            chunk = uart.read(1)
        if chunk:
            received.extend(chunk)
            if len(received) >= len(expected):
                break
        time.sleep_ms(2)
    passed = written == len(expected) and bytes(received) == expected
    print("%s trial=%d result=%s write=%s/%d rx=%d peak_any=%s" %
          (strategy, trial, "PASS" if passed else "FAIL", written,
           len(expected), len(received), peak_any if strategy == "ANY" else "NOT_USED"))
    if not passed:
        print("  expected:", show_hex(expected))
        print("  received:", show_hex(received) if received else "NONE")
    return passed


uart = None
try:
    print("UART1 LOOPBACK - TOF TX/RX MUST BE DISCONNECTED")
    print("REV2: 2026-10-17 legacy positive-timeout test")
    print("Jumper physical pin8 GPIO3 <-> physical pin10 GPIO4 ONLY")
    print("UART settings: 115200 8N1 timeout=%d" % READ_TIMEOUT_MS)
    print("Runtime:", sys.version)
    if hasattr(os, "uname"):
        print("Board:", os.uname())
    fpioa = FPIOA()
    fpioa.set_function(3, FPIOA.UART1_TXD)
    fpioa.set_function(4, FPIOA.UART1_RXD)
    uart = UART(UART.UART1, baudrate=115200, bits=UART.EIGHTBITS,
                parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE, timeout=READ_TIMEOUT_MS)
    results = {}
    for strategy in ("ANY", "DIRECT"):
        passed = 0
        for trial in range(1, 4):
            passed += 1 if check(uart, strategy, trial) else 0
        results[strategy] = passed
    print("SUMMARY ANY=%d/3 DIRECT=%d/3" % (results["ANY"], results["DIRECT"]))
    if results["ANY"] == 3 and results["DIRECT"] == 3:
        print("UART1_LOOPBACK_PASS: investigate TOF power/wiring/output next")
    elif results["DIRECT"] == 3 and results["ANY"] != 3:
        print("READ_PATH_DIFFERENCE: send complete log before changing driver")
    else:
        print("LOOPBACK_NOT_CONFIRMED: send complete log and jumper photo")
    print("Stop script, power off, remove jumper BEFORE reconnecting TOF TX/RX")
except KeyboardInterrupt:
    print("STOPPED")
except Exception as error:
    sys.print_exception(error)
finally:
    if uart is not None:
        uart.deinit()
