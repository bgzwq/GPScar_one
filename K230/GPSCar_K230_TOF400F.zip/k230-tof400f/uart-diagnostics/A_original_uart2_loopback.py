# 串口引脚自检（回环测试）- K230 庐山派
# 用法：用杜邦线把 40Pin 排针的 11 脚和 13 脚短接（TX 接回自己的 RX），
#       运行本程序，终端每 0.5s 打印一次 "收到回环: ..." 即说明引脚配置正确。
#       若收不到任何数据，检查短接位置/换引脚方案。
import time
from machine import UART, FPIOA

# 与 main.py 相同的引脚配置（排针 11 脚=GPIO5=TX，排针 13 脚=GPIO6=RX）
fpioa = FPIOA()
fpioa.set_function(5, fpioa.UART2_TXD)
fpioa.set_function(6, fpioa.UART2_RXD)
uart = UART(UART.UART2, baudrate=115200, bits=UART.EIGHTBITS,
            parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)

print("回环测试开始：请短接排针 11 脚与 13 脚")
i = 0
while True:
    uart.write("hello {}\n".format(i))
    time.sleep_ms(100)
    data = uart.read(64)          # 读取最多 64 字节
    if data:
        print("收到回环:", data)
    else:
        print("未收到回环数据，检查排针 11/13 是否短接")
    i += 1
    time.sleep_ms(400)
