# UART1 electrical-path diagnostic. Does not configure or talk to a TOF module.
# Disconnect TOF TX/RX and STM32 UART wires; keep arm and servo power OFF.
# Keep physical pin8 (GPIO3) jumpered to physical pin10 (GPIO4).
# Oscilloscope grounds go ONLY to board GND; probe tips to pin8 / pin10.
import os
import sys
import time
from machine import UART, FPIOA

RUN_SECONDS = 60
SEND_INTERVAL_MS = 100
PATTERN = bytes((0x55,)) * 64


def dump_pins(fpioa, label):
    print("PIN_CONFIG", label)
    for pin in (3, 4):
        fpioa.help(pin)
    for name, function in (("TX", FPIOA.UART1_TXD), ("RX", FPIOA.UART1_RXD)):
        mapped = []
        for pin in range(64):
            if fpioa.get_pin_func(pin) == function:
                mapped.append(pin)
        print("UART1_%s_current_GPIOs:" % name, mapped)


uart = None
try:
    print("UART1 SIGNAL PROBE - 2026-10-17")
    print("TOF and STM32 UART wires disconnected; arm power OFF")
    print("Jumper physical pin8 GPIO3 <-> physical pin10 GPIO4")
    print("Scope CH1 tip=physical8, CH2 tip=physical10, grounds=board GND")
    print("115200 8N1; 64 bytes of 0x55 every ~100ms; bit time ~8.68us")
    print("Positive timeout=10, direct reads; settings match REV2")
    print("Runtime:", sys.version)
    if hasattr(os, "uname"):
        print("Board:", os.uname())
    fpioa = FPIOA()
    fpioa.set_function(3, FPIOA.UART1_TXD)
    fpioa.set_function(4, FPIOA.UART1_RXD)
    dump_pins(fpioa, "after_FPIOA_before_UART")
    uart = UART(UART.UART1, baudrate=115200, bits=UART.EIGHTBITS,
                parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE, timeout=10)
    dump_pins(fpioa, "after_UART_init")
    started = time.ticks_ms()
    last_send = None
    last_print = started
    tx_calls = 0
    tx_accepted_bytes = 0
    rx_bytes = 0
    rx_non55 = 0
    last_rx = b""
    while time.ticks_diff(time.ticks_ms(), started) < RUN_SECONDS * 1000:
        os.exitpoint()
        now = time.ticks_ms()
        if last_send is None or time.ticks_diff(now, last_send) >= SEND_INTERVAL_MS:
            written = uart.write(PATTERN)
            if written != len(PATTERN):
                raise OSError("Partial UART write: %s/%d" % (written, len(PATTERN)))
            tx_calls += 1
            tx_accepted_bytes += written
            last_send = now
        chunk = uart.read(256)
        if chunk:
            rx_bytes += len(chunk)
            rx_non55 += sum(1 for value in chunk if value != 0x55)
            last_rx = chunk[:16]
        if time.ticks_diff(now, last_print) >= 1000:
            print("t=%d tx_calls=%d tx_accepted_bytes=%d rx_bytes=%d rx_non55=%d last_rx=%s" %
                  (time.ticks_diff(now, started), tx_calls, tx_accepted_bytes,
                   rx_bytes, rx_non55, " ".join("%02X" % value for value in last_rx)))
            last_print = now
        time.sleep_ms(2)
    dump_pins(fpioa, "end_of_test")
    print("FINISHED: software counters alone do not confirm electrical TX")
except KeyboardInterrupt:
    print("STOPPED")
except Exception as error:
    sys.print_exception(error)
finally:
    if uart is not None:
        uart.deinit()
