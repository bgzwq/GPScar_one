# Run from CanMV IDE. TOF TX -> GPIO33 (physical pin 40); common GND.
# GPIO32 is UART3 TX (physical pin 37). This test sends nothing.
import time
from machine import UART, FPIOA

fpioa = FPIOA()
fpioa.set_function(32, FPIOA.UART3_TXD)
fpioa.set_function(33, FPIOA.UART3_RXD)
uart = UART(UART.UART3, baudrate=115200, bits=UART.EIGHTBITS,
            parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE, timeout=10)
try:
    print("TOF UART3 RX ONLY | GPIO33 RX | 115200 8N1")
    total = 0
    for i in range(100):
        time.sleep_ms(100)
        data = uart.read(64)
        if data:
            total += len(data)
            print("RX=" + " ".join("%02X" % value for value in data))
        elif i % 10 == 9 and total == 0:
            print("Waiting for TOF auto-report; total_rx=0")
    print("FINISHED total_rx=%d" % total)
finally:
    uart.deinit()
