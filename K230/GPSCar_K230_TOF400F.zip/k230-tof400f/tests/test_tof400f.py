"""Run on PC: python -m unittest discover -s tests -v"""
import importlib.util
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

MODULE = Path(__file__).resolve().parents[1] / "tof400f.py"
spec = importlib.util.spec_from_file_location("tof400f", MODULE)
tof = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tof)


def response(distance, address=1):
    return tof.with_crc(bytes((address, 3, 2, distance >> 8, distance & 255)))


class ProtocolTests(unittest.TestCase):
    def test_vendor_query_vector(self):
        self.assertEqual(tof.read_distance_request(), bytes.fromhex("01 03 00 10 00 01 85 CF"))

    def test_vendor_reply_vector(self):
        events = tof.FrameParser().feed(bytes.fromhex("01 03 02 00 65 78 6F"))
        self.assertEqual([(k, v) for k, v, _ in events], [("distance", 101)])

    def test_all_fragment_boundaries(self):
        frame = response(325)
        for split in range(1, len(frame)):
            parser = tof.FrameParser()
            self.assertEqual(parser.feed(frame[:split]), [])
            self.assertEqual(parser.feed(frame[split:])[0][1], 325)

    def test_bytewise_receive(self):
        parser = tof.FrameParser()
        events = []
        for value in response(600):
            events.extend(parser.feed(bytes((value,))))
        self.assertEqual(events[0][1], 600)

    def test_noise_corruption_and_recovery(self):
        parser = tof.FrameParser()
        broken = bytearray(response(200))
        broken[4] ^= 0x01
        events = parser.feed(b"noise" + bytes(broken) + response(301))
        self.assertEqual([v for k, v, _ in events if k == "distance"], [301])
        self.assertGreater(parser.crc_errors, 0)

    def test_coalesced_frames(self):
        events = tof.FrameParser().feed(response(200) + response(201))
        self.assertEqual([v for _, v, _ in events], [200, 201])

    def test_foreign_address_and_query_echo(self):
        events = tof.FrameParser().feed(response(50, address=2) +
                                        tof.read_distance_request() + response(150))
        self.assertEqual([v for _, v, _ in events], [150])

    def test_write_ack_does_not_become_range(self):
        ack = tof.with_crc(bytes((1, 6, 0, 4, 0, 0)))
        self.assertEqual(tof.FrameParser().feed(ack)[0][:2], ("write_ack", 4))

    def test_modbus_exception(self):
        error = tof.with_crc(bytes((1, 0x83, 2)))
        self.assertEqual(tof.FrameParser().feed(error)[0][:2], ("exception", 2))

    def test_buffer_bounded_and_recovers(self):
        parser = tof.FrameParser()
        events = parser.feed(b"x" * 10000 + response(220))
        self.assertLessEqual(len(parser.buffer), 256)
        self.assertEqual(events[0][1], 220)

    def test_truncated_frame_then_valid_frame(self):
        parser = tof.FrameParser()
        self.assertEqual(parser.feed(response(100)[:4]), [])
        events = parser.feed(response(250))
        self.assertEqual(events[0][1], 250)


class HistoryTests(unittest.TestCase):
    def test_normal_poll_cadence_can_fill_window(self):
        history = tof.RangeHistory()
        for i in range(5):
            history.record(200 + i, 120 * i)
        self.assertEqual(history.snapshot(480)["status"], "STABLE_RX")
        self.assertEqual(history.snapshot(480)["median_mm"], 202)

    def test_invalid_measurement_clears_old_filter(self):
        for invalid in (0, 0xFF00, 0xFFFF, 4001):
            history = tof.RangeHistory()
            history.record(200, 0)
            history.record(invalid, 10)
            state = history.snapshot(10)
            self.assertEqual(state["status"], "INVALID")
            self.assertIsNone(state["median_mm"])
            self.assertIsNone(state["raw_mm"])

    def test_timeout_never_displays_old_distance_as_current(self):
        history = tof.RangeHistory()
        history.record(200, 0)
        state = history.snapshot(history.fresh_ms + 1)
        self.assertEqual(state["status"], "STALE")
        self.assertIsNone(state["median_mm"])
        self.assertIsNone(state["raw_mm"])

    def test_restart_after_gap_has_to_warm_up(self):
        history = tof.RangeHistory()
        history.record(100, 0)
        history.record(300, history.fresh_ms + 1)
        state = history.snapshot(history.fresh_ms + 1)
        self.assertEqual(state["status"], "WARMUP")
        self.assertEqual(state["median_mm"], 300)
        self.assertEqual(state["count"], 1)

    def test_unstable_numbers(self):
        history = tof.RangeHistory()
        for i, distance in enumerate((100, 140, 200, 250, 300)):
            history.record(distance, i * 10)
        self.assertEqual(history.snapshot(40)["status"], "UNSTABLE")

    def test_modbus_exception_clears_last_range(self):
        history = tof.RangeHistory()
        history.record(200, 0)
        history.invalidate("EXCEPTION_02", 10)
        self.assertIsNone(history.snapshot(10)["raw_mm"])


class FakeUART:
    def __init__(self):
        self.rx = bytearray()
        self.sent = []

    def any(self):
        return len(self.rx)

    def read(self, count):
        data = bytes(self.rx[:count])
        del self.rx[:count]
        return data

    def write(self, data):
        self.sent.append(bytes(data))
        return len(data)


class IntegrationTests(unittest.TestCase):
    def test_receive_does_not_depend_on_any_zero_timeout_poll(self):
        uart = FakeUART()
        uart.any = lambda: 0
        uart.rx.extend(response(150))
        self.assertEqual(tof.TOF400F(uart).update(0)["raw_mm"], 150)

    def test_k230_constructor_uses_positive_timeout_for_legacy_firmware(self):
        calls = []

        class UART:
            UART1 = 1
            EIGHTBITS = 8
            PARITY_NONE = 0
            STOPBITS_ONE = 1

            def __init__(self, *args, **kwargs):
                calls.append((args, kwargs))

        class FPIOA:
            UART1_TXD = 1
            UART1_RXD = 2

            def set_function(self, *args):
                pass

        machine = types.SimpleNamespace(UART=UART, FPIOA=FPIOA)
        with patch.dict(sys.modules, {"machine": machine}):
            tof.open_k230_uart()
        self.assertGreater(calls[0][1]["timeout"], 0)

    def test_only_read_queries_and_no_burst_after_pause(self):
        uart = FakeUART()
        driver = tof.TOF400F(uart)
        for stamp in (0, 1, 119, 120, 10000):
            driver.update(stamp)
        self.assertEqual(len(uart.sent), 3)
        self.assertTrue(all(data == tof.read_distance_request() for data in uart.sent))

    def test_receive_then_invalid_then_timeout(self):
        uart = FakeUART()
        driver = tof.TOF400F(uart)
        uart.rx.extend(response(150))
        self.assertEqual(driver.update(0)["raw_mm"], 150)
        uart.rx.extend(response(0xFFFF))
        self.assertEqual(driver.update(1)["status"], "INVALID")
        self.assertEqual(driver.update(10000)["status"], "STALE")

    def test_partial_transmission_is_reported(self):
        uart = FakeUART()
        uart.write = lambda data: 3
        with self.assertRaises(OSError):
            tof.TOF400F(uart).update(0)

    def test_tick_wraparound(self):
        original = tof.ticks_diff
        period = 1 << 30
        tof.ticks_diff = lambda a, b: ((a - b + period // 2) % period) - period // 2
        try:
            history = tof.RangeHistory()
            history.record(150, period - 20)
            self.assertEqual(history.snapshot(10)["age_ms"], 30)
            self.assertEqual(history.snapshot(10)["raw_mm"], 150)
            self.assertEqual(history.snapshot(1000)["status"], "STALE")
            uart = FakeUART()
            driver = tof.TOF400F(uart)
            driver.update(period - 20)
            driver.update(10)
            driver.update(110)
            self.assertEqual(len(uart.sent), 2)
        finally:
            tof.ticks_diff = original


if __name__ == "__main__":
    unittest.main()
